@extends('layouts.app')

@section('content')
    <city > </city>
@endsection
