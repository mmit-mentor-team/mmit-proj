@extends('layouts.app')
@section('content')

<company></company>

@endsection