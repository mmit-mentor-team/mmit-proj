@extends('layouts.app')

@section('content')
    <course></course>
@endsection
