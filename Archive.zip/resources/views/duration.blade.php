@extends('layouts.app')

@section('content')
    <duration></duration>
@endsection
