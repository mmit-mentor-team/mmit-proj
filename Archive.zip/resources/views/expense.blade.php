@extends('layouts.app')

@section('content')
    <expense> </expense>
@endsection
