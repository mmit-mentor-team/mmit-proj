@extends('layouts.app')

@section('content')
    <income> </income>
@endsection
