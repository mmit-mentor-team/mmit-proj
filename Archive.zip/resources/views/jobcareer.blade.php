@extends('layouts.app')

@section('content')
    <jobcareer> </jobcareer>
@endsection