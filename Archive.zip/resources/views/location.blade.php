@extends('layouts.app')

@section('content')
    <location></location>
@endsection
