@extends('layouts.app')

@section('content')
    <permission> </permission>
@endsection
