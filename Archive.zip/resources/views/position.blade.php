@extends('layouts.app')

@section('content')
	<position></position>	
@endsection