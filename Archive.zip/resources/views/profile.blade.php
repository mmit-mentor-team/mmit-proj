@extends('layouts.app')
@section('content')

	<profile></profile>

@endsection