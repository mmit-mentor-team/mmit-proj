@extends('layouts.app')

@section('content')
    <role> </role>
@endsection