@extends('layouts.app')

@section('content')
    <teacher> </teacher>
@endsection
