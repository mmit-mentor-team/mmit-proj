<?php $__env->startSection('content'); ?>
    <location></location>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gittesting/mmit/resources/views/location.blade.php ENDPATH**/ ?>