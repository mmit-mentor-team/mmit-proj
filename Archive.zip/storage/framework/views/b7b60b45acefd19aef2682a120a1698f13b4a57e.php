<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">



  <title> MMIT Consulting </title>

  <!-- Custom fonts for this template -->
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">


  <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <!-- Favicon -->
  <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('img/favicon.jpg')); ?>">

  <!-- Scripts -->
  <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

  <!-- Styles -->
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
  
</head>

  
  <?php if(Request::segment(1) == '' || Request::segment(1) == 'login' || Request::segment(1) == 'register' || Request::segment(1) == 'print' ): ?>

    <body class="bg-gradient-primary">
    <?php echo $__env->yieldContent('content'); ?>

  <?php else: ?>
    <body id="page-top">
    <?php echo $__env->make('part.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php endif; ?>




</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gittesting/mmit/resources/views/layouts/app.blade.php ENDPATH**/ ?>