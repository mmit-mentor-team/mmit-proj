<?php $__env->startSection('content'); ?>
    <teacher> </teacher>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel_project/mic-trainging-one/resources/views/teacher.blade.php ENDPATH**/ ?>