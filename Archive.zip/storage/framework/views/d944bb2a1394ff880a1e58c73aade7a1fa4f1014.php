<?php $__env->startSection('content'); ?>
    <inquire :permissions="<?php echo e(Auth::user()->permissions); ?>" :active_tab="hr_ygn"> </inquire>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/laravel_project/mic-trainging-one/resources/views/inquire.blade.php ENDPATH**/ ?>