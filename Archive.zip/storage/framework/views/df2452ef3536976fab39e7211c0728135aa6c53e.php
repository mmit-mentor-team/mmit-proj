<?php $__env->startSection('content'); ?>
    <course></course>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gittesting/mmit/resources/views/course.blade.php ENDPATH**/ ?>