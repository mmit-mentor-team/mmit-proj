<?php $__env->startSection('content'); ?>
    <permission> </permission>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/gittesting/mmit/resources/views/permission.blade.php ENDPATH**/ ?>